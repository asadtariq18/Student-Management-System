package semesterproject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Scanner;

public class SemesterProject {

    private static Object java;

    public static void main(String[] args) {

        System.out.print("\n**********STUDENT MANAGEMENT SYSTEM**********\n");
        int passCount = 1;
        while (passCount < 4) {
            System.out.print("\nLOG IN AS ADMIN\n");                                //Login to the program
            System.out.println("\n(Username: admin\tPassword: 1234)\n");
            Scanner input = new Scanner(System.in);
            System.out.print("Enter Username: ");
            String user = input.nextLine();
            System.out.print("Password: ");
            String password = input.nextLine();
            if (user.equalsIgnoreCase("admin") && password.equals("1234")) {        //Checks password and Username (if valid)

                int num = 0;

                while (num != 7) {
                    try {

                        System.out.println("\nPRESS GIVEN KEYS TO PERFORM ACTION\n\n 1:\tStudent Portal\n 2:\tTake Attendence\n 3:\tView Attendence Status\n 4:\tUpdate Marks\n 5:\tView Marks Summary\n 6:\tView Students Record\n 7:\tExit");
                        System.out.print("\nEnter an integer: ");

                        num = input.nextInt();

                        switch (num) {                                              //Main Menu Options (Select any of them)

                            case 1: {
                                StudentPortal();                                    //Performs actions like adding, searching, removing and editing student info
                                break;
                            }
                            case 2: {
                                TakeAttendence();                                       //takes attendence of added students
                                WhereToGo();
                                break;
                            }
                            case 3: {
                                ViewAttendence();
                                WhereToGo();
                                break;
                            }
                            case 4: {
                                UpdateMarks();                                      //to update marks of added students
                                WhereToGo();
                                break;
                            }
                            case 5: {
                                ViewMarksSummary();
                                WhereToGo();
                                break;
                            }
                            case 6: {
                                ViewRecord();                                       //to view added students list
                                WhereToGo();
                                break;
                            }
                            case 7: {                                               //In case you want to exit the program

                                System.out.println("PROGRAM EXITED SUCCESSFULLY\n");
                                System.exit(0);
                                break;

                            }
                            default: {                                              //in case user input is not suitable (not an above given number)
                                System.out.print("PLEASE ENTER VALID INPUT\n");

                            }

                        }

                    } catch (Exception e) {                                         //in case user input is not an integer
                        System.out.println("PLEASE ENTER AN INTEGER");
                        return;
                    }
                }
            } else {                                                                //In case entered password or username is incorrect

                System.out.println("Wrong Password or Username (" + (3 - passCount) + " attempt/s left)");
                passCount++;
            }
        }
        System.out.println("\nTOO MANY WRONG ATTEMPTS, PROGRAM TERMINATED");
    }

    public static void StudentPortal() {
        int exitCount = 0;
        try {

            while (exitCount == 0) {
                Scanner input = new Scanner(System.in);
                System.out.println("\nPRESS FOLLOWING KEY TO PERFORM ACTION\n\n 1:\tAdd Student\n 2:\tSearch Student\n 3:\tRemove Student\n 4:\tBack to Main Menu");
                System.out.print("\nEnter an integer: ");
                int num = input.nextInt();

                switch (num) {

                    case 1: {
                        AddStudent();                                           //to add new students 
                        return;

                    }
                    case 2: {
                        SearchStudent();                                        //to search from added students
                        WhereToGo();
                        return;
                    }
                    case 3: {
                        RemoveStudent();                                        //to remove any of the added students
                        WhereToGo();
                        return;
                    }
                    case 4: {                                                   //in case user wants to return to main menu

                        return;

                    }
                    default: {                                                  //in case the input entered is not correct

                        System.out.print("\nPLEASE ENTER A VALID INPUT");
                    }

                }

            }
        } catch (Exception e) {

            System.out.println("PLEASE! ENTER AN INTEGER");
            StudentPortal();
        }
    }

    public static void AddStudent() {
        try {

            java.io.File file = new java.io.File("Data.txt");                   //Creating a text file to store students info
            java.io.FileWriter fw = new FileWriter(file, true);                 //appending the data if file already exists
            try (java.io.BufferedWriter bw = new java.io.BufferedWriter(fw)) {

                int exitCount = 1;
                while (exitCount == 1) {

                    System.out.print("\nHow many students you want to add: ");
                    Scanner input = new Scanner(System.in);
                    int n = input.nextInt();                                    //gets an integer as number of students

                    for (int i = 0; i < n; i++) {
                        System.out.println("\nENTER STUDENT INFO");

                        System.out.print("\nStudent First Name: ");
                        String fname = input.next();                            //gets firstname from user

                        System.out.print("\nStudent Last Name: ");
                        String sname = input.next();                            //getting last name

                        System.out.print("\nRegistration number: ");
                        String rnum = input.next();                             //getting registration number of student

                        bw.write(fname + " " + sname + "\t\t" + rnum + "\n");       // writing the above given data to the text file
                        bw.newLine();

                    }

                    bw.close();

                    System.out.println("\nPress '1' to add more students\nPress '2' to return to Main Menu\nPress any other key to exit");
                    exitCount = input.nextInt();
                    if (exitCount == 1) {

                    } else if (exitCount == 2) {
                        return;
                    } else {
                        System.exit(0);
                    }

                }
            }

        } catch (Exception e) {                                                 //in case user input is not valid
            System.out.println("\nINVALID INPUT, Please Enter an Integer\n");
            AddStudent();

        }

    }

    public static void TakeAttendence() {
        Scanner input = new Scanner(System.in);
        int count = 0;
        try {

            File file = new File("Data.txt");                                   //Accessing the file    
            Scanner read = new Scanner(file);                                   //importing a scanner to read from the text file

            if (file.exists()) {
                java.io.File attFile = new java.io.File("Attendence.txt");          //creating a new text file (not appending)
                java.io.PrintWriter write = new java.io.PrintWriter(attFile);

                System.out.println("\n***** IT'S ATTENDENCE TIME *****\n");
                SimpleDateFormat formatter = new SimpleDateFormat("'Date: 'dd-MM-yyyy' | Time: 'HH:mm:ss");
                Date date = new Date(System.currentTimeMillis());
                System.out.println("\n" + formatter.format(date) + "\n");
                write.println("\n");
                write.print(formatter.format(date) + "\n");
                write.println("\n");
                write.println("NO.\tSTUDENT NAME\t\tREG. NUMBER\t\tSTATUS");
                write.println();

                int num = 1;
                int present = 0;
                int absent = 0;
                while (read.hasNext()) {                                            //reading from the file of added students

                    String student = read.nextLine();

                    if (!read.nextLine().equals(" ")) {                                    //making sure the line is not empty
                        int n = 0;
                        while (n == 0) {                                            //to keep asking for valid input until the user enters
                            String s;

                            System.out.println(num + ".\t" + student);
                            System.out.println("\tP: Present\tA: Absent");

                            s = input.next();                                           //getting input for students status

                            if (s.equalsIgnoreCase("p")) {
                                write.print(num + ".\t" + student + "\t\tPRESENT");     //writing the status in the file
                                write.println("");
                                present++;
                                num++;
                                n = 1;
                            } else if (s.equalsIgnoreCase("a")) {
                                write.print(num + ".\t" + student + "\t\tABSENT");
                                write.println("");
                                absent++;
                                num++;
                                n = 1;
                            } else {                                                //in case user enter invalid input (other than 'p' and 'a')
                                System.out.println("ENTER VALID INPUT:(P: Present\tA: Absent)\n");
                                n = 0;
                            }

                        }
                    }
                }
                write.print("\nATTENDENCE DETAIL\nPresents:\t" + present + "\nAbsents:\t" + absent);
                read.close();                                                       //closing the read  (necessary)
                write.close();                                                      //closing write (necessary)
                System.out.println("-----ATTENDENCE SUCCESSFULLY UPDATED-----");
            }
        } catch (Exception e) {                                                 //In case file is empty or doesn't exist.
            System.out.print("NO RECORD AVAILABLE. Add students first\n");

        }
    }

    public static void ViewAttendence() {
        try {
            File att = new File("Attendence.txt");                              //Accessing the file in directory
            Scanner read = new Scanner(att);
            if (read.hasNext()) {                                               //checking if the file is not empty
                while (read.hasNext()) {

                    System.out.print(read.nextLine() + "\n");                   //printing out the line read by the scanner

                }
            } else {                                                            //in case the file is empty

                System.out.print("ATTENDENCE NOT TAKEN YET, Take Attendence first");
            }
        } catch (FileNotFoundException ex) {                                    //in case file doesnt exist
            System.out.print("FILE DOES NOT EXIST, Take Attendence first");
        }

    }

    public static void ViewRecord() throws IOException {

        try {
            File data = new File("data.txt");                                   //Accessing the file
            Scanner read = new Scanner(data);

            if (read.hasNext()) {                                               //if the file is not empty
                Scanner input = new Scanner(System.in);
                System.out.print("PRESS GIVEN KEYS TO VIEW SORTED LIST\n\n1:\tSort by Name\n2:\tSort by Registeration Number\n3:\tSort by time\n\nEnter an Integer: ");
                int option = input.nextInt();                                   //getting user's option as input
                switch (option) {

                    case 1: {
                        SortByName();                                           //calling the method to sort the record by name
                        break;
                    }
                    case 2: {
                        SortByReg();                                            //calling the method to sort the record by reg no.    
                        break;
                    }
                    case 3: {
                        SortByTime();                                           //calling the method to sort the record by time
                        break;
                    }
                    default: {                                                  //in case user enters wrong input
                        System.out.print("PLEASE ENTER VALID INPUT\n\n");
                        ViewRecord();
                    }
                }
            } else {                                                            //if the file is empty
                System.out.print("\nNO RECORD AVAILABLE, Add Students first\n");
            }

        } catch (FileNotFoundException e) {                                     //if the file does not exist
            System.out.print("\nFILE DOES NOT EXIST, Add Students first\n");

        }

    }

    public static void UpdateMarks() {

        try {

            File file = new File("Data.txt");                                   //Accessing the file
            Scanner read = new Scanner(file);
            Scanner input = new Scanner(System.in);
            File f = new File("Marks.txt");                                     //Creating a new file to store marks
            PrintWriter write = new PrintWriter(f);
            if (read.hasNext()) {                                               //if the file is not empty

                System.out.println("----UPDATE STUDENTS MARKS----\n");
                System.out.print("\nTotal Marks: ");
                int tmarks = input.nextInt();                                   //getting total marks from user as an input
                write.println();
                write.println("NO.\tSTUDENT NAME\t\tREG. NUMBER\t\tMARKS OBTAINED\t\tTOTAL MARKS\t\tPERCENTAGE");
                write.println();
                int num = 1;
                while (read.hasNext()) {
                    String student = read.nextLine();

                    if (read.nextLine() != "") {                                //if the line to be printed is not empty

                        int n = 1;
                        while (n == 1) {
                            System.out.println("\n" + num + ".\t" + student);
                            System.out.print("\nMarks Obtained: ");
                            int omarks = input.nextInt();                       //getting obtained marks 

                            if (omarks >= 0 && omarks <= tmarks) {              //checkin domain obtained marks  
                                write.print(num + ".\t" + student + "\t\t " + omarks + "\t\t\t" + tmarks + "\t\t\t" + ((long) (omarks * 100 / tmarks)) + "%");          //writing the marks of each student into a file
                                write.println();
                                n = 0;
                            } else {                                            //if obtained marks are more than total marks or less than 0
                                System.out.println("PLEASE ENTER MARKS WITHIN 0-" + tmarks);
                                n = 1;
                            }
                        }
                        num++;
                    }

                }
                System.out.println("\n-----MARKS UPDATED SUCCESSFULLY------");

            } else {                                                            //if the file is empty
                System.out.print("NO RECORD AVAILABLE. Add Students first");
            }
            read.close();
            write.close();

        } catch (FileNotFoundException e) {                                     //if the file does not exist
            System.out.println("NO RECORD AVAILABLE. Add Students first");

        }

    }

    public static void ViewMarksSummary() {

        try {
            File marks = new File("Marks.txt");                                 //Accessing the file
            Scanner read = new Scanner(marks);
            if (read.hasNext()) {                                               //if the file is not empty
                while (read.hasNext()) {

                    System.out.print(read.nextLine() + "\n");

                }
            } else {                                                            //if the file is empty

                System.out.print("MARKS NOT UPDATED YET, Update Marks first");
            }
        } catch (FileNotFoundException ex) {                                    //if the file does not exist
            System.out.print("FILE DOES NOT EXIST, Update Marks first");
        }

    }

    public static void SearchStudent() {
        File file = new File("Data.txt");                                       //Accessing the file

        Scanner read;
        Scanner input = new Scanner(System.in);
        try {

            read = new Scanner(file);
            if (read.hasNext()) {

                System.out.print("Search by Registraion Number: ");
                String rSearch = input.next();
                boolean found = false;
                while (read.hasNext()) {
                    String student = read.nextLine();
                    if (student.contains(rSearch)) {                            //check if the search has found
                        found = true;
                        System.out.println("\n" + student);
                    }

                }
                if (!found) {                                                   //if search is not found

                    System.out.println("\nNO MATCH FOUND");

                }
                read.close();

            }
        } catch (Exception e) {
            System.out.println("NO RECORD FOUND. Add Students first");

        }
    }

    public static void RemoveStudent() {

        try {

            SortByTime();                                                       //Displaying the list of student to choose which one to be removed
            File sourcefile = new File("Data.txt");
            Scanner sourceread = new Scanner(sourcefile);

            Scanner input = new Scanner(System.in);

            if (sourceread.hasNext()) {
                System.out.print("\n\nEnter Registration number you want to remove: ");
                String rStudent = input.next();

                File newfile = new File("temp.txt");                            //Creating a temporary file
                FileWriter fw = new FileWriter(newfile);
                PrintWriter tempWriter = new PrintWriter(fw);
                boolean found = false;
                while (sourceread.hasNext()) {                                  //reading from source file
                    String student = sourceread.nextLine();

                    if (!student.contains(rStudent)) {

                        tempWriter.write(student);                              //writing in temporary file
                        tempWriter.write("\n");

                    } else {
                        found = true;
                    }

                }

                tempWriter.close();
                if (found == true) {
                    Scanner tempread = new Scanner(newfile);
                    PrintWriter sourceWriter = new PrintWriter(new FileWriter(sourcefile));
                    while (tempread.hasNext()) {                                //Reading from temporary file

                        sourceWriter.write(tempread.nextLine());                //Writing in source file
                        sourceWriter.write("\n");

                    }

                    tempread.close();
                    sourceWriter.close();
                    sourceread.close();
                    newfile.delete();
                    System.out.println("\n\nSTUDENT REMOVED SUCCESSFULLY");
                } else {                                                        //if the reg number not found
                    System.out.println("Not available or already removed");
                }
            }

        } catch (Exception e) {                                                 //if the source file is empty
            System.out.println("NO RECORD FOUND. Add Students first");

        }

    }

    public static void SortByName() throws IOException {

        File file = new File("Data.txt");                                       //Accessing the file
        BufferedReader br = new BufferedReader(new FileReader(file));

        ArrayList<String> stds = new ArrayList<String>();                       //creating array list of string
        System.out.print("STUDENT NAME\t\tREG. NUMBER\n\n");
        while (br.ready()) {                                                    //reading from the file

            String student = br.readLine();
            stds.add(student);

        }
        br.close();                                                             //closing reader

        Collections.sort(stds, String.CASE_INSENSITIVE_ORDER);                  //making a sorted collection
        for (String s : stds) {                                                 //printing out linewise
            System.out.println(s);
        }

    }

    public static void SortByReg() throws IOException {                         //sorts the students by reg. numbers
        File file = new File("Data.txt");                                       //accessing the file
        BufferedReader br = new BufferedReader(new FileReader(file));

        ArrayList<String> stds = new ArrayList<String>();                       //creating array list of string
        System.out.print("STUDENT NAME\t\tREG. NUMBER\n\n");
        while (br.ready()) {                                                    //reading from the file

            String student = br.readLine();
            stds.add(student);

        }
        br.close();                                                             //closing reader

        Collections.sort(stds, new Comparator<String>() {                       //creating a collection of students
            public int compare(String o1, String o2) {                          //comparing reg numbers to sort
                return extractInt(o1) - extractInt(o2);
            }

            int extractInt(String s) {
                String num = s.replaceAll("\\D", "");
                // return 0 if no digits found
                return num.isEmpty() ? 0 : Integer.parseInt(num);
            }
        });
        for (String s : stds) {                                                 //printing line by line
            System.out.println(s);
        }

    }

    public static void SortByTime() throws FileNotFoundException {

        java.io.File file = new java.io.File("Data.txt");                   //Accessing the stored data

        int num = 1;                                                        //numbering the list

        Scanner read = new Scanner(file);
        if (read.hasNext()) {                                               //checking if the file not empty
            System.out.println("\nNO.\tSTUDENT NAME\t\tREG. NUMBER\n");
            while (read.hasNext()) {

                String student = read.nextLine();
                if (!student.isEmpty()) {                                   //making sure the line to be printed is not empty
                    System.out.println(num + ".\t" + student);
                    num++;
                }

            }
        } else {                                                                //if the file is empty

            System.out.println("FILE IS EMPTY, Add students first");
        }

    }

    public static void WhereToGo() {                                            //asks the user for next possible actions

        int exitCount = 0;
        Scanner input = new Scanner(System.in);
        System.out.println("\n Press '1' for Main menu, any other key to exit");
        exitCount = input.nextInt();                                            //asking user to enter choice
        if (exitCount == 1) {
            return;                                                             //returns to main
        } else {
            System.exit(0);                                                     //yerminates the program
        }

    }
}
